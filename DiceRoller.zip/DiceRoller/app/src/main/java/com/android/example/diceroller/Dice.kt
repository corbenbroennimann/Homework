package com.android.example.diceroller

import android.widget.ImageView
import java.sql.SQLTransactionRollbackException
import kotlin.random.Random

class Dice(imageView : ImageView) {

    private val diceImage = imageView
    var held = false
    var roll = 1


    fun setImageByRoll(rolled:Int) {
        val image = when (rolled) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }
        diceImage.setImageResource(image)
        roll = rolled
    }

    fun randomRoll() : Int {
        if(!held) {
            roll = Random.nextInt(1, 7)
            setImageByRoll(roll)
        }
        return roll
    }
}