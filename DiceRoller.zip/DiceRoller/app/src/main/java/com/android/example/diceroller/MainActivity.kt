package com.android.example.diceroller

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import org.w3c.dom.Text
import java.util.*
import java.util.concurrent.DelayQueue
import java.util.concurrent.Delayed
import kotlin.collections.ArrayList
import kotlin.math.sqrt
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    //private var savedScore = 0
    private var totalScore = 0
    private var rerollTracker = 3

    private var sensorManager: SensorManager? = null
    private var acceleration = 0f
    private var currentAcceleration = 0f
    private var lastAcceleration = 0f

    private var rollArray = arrayListOf<Int>(1,1,1,1,1)
    private var heldArray = arrayListOf<Int>(0,0,0,0,0)

    private lateinit var d1 : Dice
    private lateinit var d2 : Dice
    private lateinit var d3 : Dice
    private lateinit var d4 : Dice
    private lateinit var d5 : Dice

    private lateinit var diceList : List<Dice>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        val rollButton: Button = findViewById(R.id.roll)

        val saveButton: Button = findViewById(R.id.saveScore)


        Objects.requireNonNull(sensorManager)!!
            .registerListener(sensorListener, sensorManager!!
                .getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL)

        acceleration = 10f
        currentAcceleration = SensorManager.GRAVITY_EARTH
        lastAcceleration = SensorManager.GRAVITY_EARTH

        d1 = Dice(findViewById(R.id.die_1))
        d2 = Dice(findViewById(R.id.die_2))
        d3 = Dice(findViewById(R.id.die_3))
        d4 = Dice(findViewById(R.id.die_4))
        d5 = Dice(findViewById(R.id.die_5))

        diceList = listOf(d1,d2,d3,d4,d5)

        //saves the current score and resets the activity
        saveButton.setOnClickListener {
            totalScore += rollArray.sum()
            findViewById<TextView>(R.id.totalScore).text  = "Total Score: $totalScore"
            resetValues()
        }

        //rolls all dice on click
        rollButton.setOnClickListener {
            rerollHandler()
        }
        //Listeners for each die to selected and held
        findViewById<ImageView>(R.id.die_1).setOnClickListener {
            heldClickLogic(d1,0)
        }

        findViewById<ImageView>(R.id.die_2).setOnClickListener {
            heldClickLogic(d2,1)
        }

        findViewById<ImageView>(R.id.die_3).setOnClickListener {
            heldClickLogic(d3,2)
        }

        findViewById<ImageView>(R.id.die_4).setOnClickListener {
            heldClickLogic(d4,3)
        }

        findViewById<ImageView>(R.id.die_5).setOnClickListener {
            heldClickLogic(d5,4)
        }
        rollAllDice()
    }

    private val sensorListener: SensorEventListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {

            // Fetching x,y,z values
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]
            lastAcceleration = currentAcceleration

            // Getting current accelerations
            // with the help of fetched x,y,z values
            currentAcceleration = sqrt((x * x + y * y + z * z).toDouble()).toFloat()
            val delta: Float = currentAcceleration - lastAcceleration
            acceleration = acceleration * 0.9f + delta

            // Display a Toast message if
            // acceleration value is over 12
            if (acceleration > 12) {
                Toast.makeText(applicationContext, "Shake event detected", Toast.LENGTH_SHORT).show()
                rerollHandler()
            }
        }
        override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
    }
    //saves the state of the activity
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("reroll_track", rerollTracker)
        outState.putInt("total_score", totalScore)
        outState.putInt("saved_score", rollArray.sum())
        outState.putIntegerArrayList("number_array", rollArray)
        outState.putIntegerArrayList("boolean_array", heldArray)
    }

    //restores the state of the activity
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        rerollTracker = savedInstanceState.getInt("reroll_track", 3)
        totalScore = savedInstanceState.getInt("total_score", 0)
        rollArray = savedInstanceState.getIntegerArrayList("number_array") as ArrayList<Int>
        heldArray = savedInstanceState.getIntegerArrayList("boolean_array") as ArrayList<Int>
        assertHeld()
        assertRoll()
        findViewById<TextView>(R.id.rerollTracker).text = "Rerolls Left: ${rerollTracker.toString()}"
        findViewById<TextView>(R.id.totalScore).text = "Total Score: ${totalScore.toString()}"
        findViewById<TextView>(R.id.currScore).text = "Current Score: ${rollArray.sum().toString()}"
    }

    override fun onResume() {
        sensorManager?.registerListener(sensorListener, sensorManager!!.getDefaultSensor(
            Sensor .TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL
        )
        super.onResume()
    }

    override fun onPause() {
        sensorManager!!.unregisterListener(sensorListener)
        super.onPause()
    }


    //Rolls all dice within the activity and adjusts array tracker
    private fun rollAllDice() {
        for(i in diceList.indices) {
            rollArray[i] = diceList[i].randomRoll()
        }
        findViewById<TextView>(R.id.currScore).text = "Current Score: ${rollArray.sum()}"
    }

    //Will reset the core values of the activity
    private fun resetValues(){
        rerollTracker = 3
        revertHeld()
        findViewById<TextView>(R.id.rerollTracker).text = "Rerolls Left: $rerollTracker"
        rollAllDice()
    }

    //handles the logic around tracking rerolls
    private fun rerollHandler(){
        rerollTracker--
        if(rerollTracker <= 0) {
            totalScore += rollArray.sum()
            findViewById<TextView>(R.id.totalScore).text  = "Total Score: $totalScore"
            resetValues()
        } else {
            findViewById<TextView>(R.id.rerollTracker).text = "Rerolls Left: $rerollTracker"
            rollAllDice()
        }
    }
    //Tells activity when a dice has been held
    private fun heldClickLogic(dice : Dice, index: Int){
        if(!dice.held) {
            dice.held = true
            heldArray[index] = 1
        } else {
            dice.held = false
            heldArray[index] = 0
        }
    }
    //used when rerolls are used up
    private fun revertHeld(){
        for(i in diceList.indices) {
            diceList[i].held = false
        }
    }
    //used for ensuring selected held dice persist
    private fun assertHeld(){
        for(i in diceList.indices) {
            if (heldArray[i] > 0) {
                diceList[i].held = true
            }
        }
    }
    //used for ensuring dices' rolled values persist
    private fun assertRoll(){
        for(i in diceList.indices) {
            diceList[i].setImageByRoll(rollArray[i])
        }
    }




}